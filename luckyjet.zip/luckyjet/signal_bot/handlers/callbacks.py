from aiogram import Router, filters, F
from aiogram.types import Message, CallbackQuery
from ..keyboards import reply, inline


router_callbacks = Router()